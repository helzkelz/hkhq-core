<template>
  <div v-if="visible" class="fixed inset-0 z-50 bg-black bg-opacity-60 flex items-center justify-center">
    <div class="bg-gray-900 text-white rounded-lg shadow-xl p-6 w-full max-w-md">
      <h2 class="text-2xl font-bold mb-3">Alignment Inquiry</h2>
      <p class="text-sm text-gray-300 mb-4">Submit your intentions. Our ethically-questionable backend logic will ponder them deeply.</p>
      <textarea
        v-model="message"
        placeholder="Type your cryptic message here..."
        class="w-full bg-gray-800 border border-gray-700 rounded p-3 mb-4 resize-none text-sm text-white placeholder-gray-500"
        rows="4"
      ></textarea>
      <div class="flex justify-end space-x-2">
        <button
          @click="sendInquiry"
          class="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-white font-medium"
          :disabled="loading"
        >
          {{ loading ? 'Sending...' : 'Send' }}
        </button>
        <button @click="$emit('close')" class="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded text-white font-medium">
          Cancel
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'InquiryModal',
  props: {
    visible: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      message: '',
      loading: false
    };
  },
  methods: {
    async sendInquiry() {
      if (!this.message.trim()) return;
      this.loading = true;
      try {
        console.log('Sending inquiry:', this.message);
        // TODO: replace with real backend endpoint
        await new Promise(resolve => setTimeout(resolve, 1000));
        this.$emit('close');
        this.message = '';
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>
