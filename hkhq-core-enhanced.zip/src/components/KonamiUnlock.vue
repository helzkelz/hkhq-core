<template>
  <div v-if="unlocked" class="fixed inset-0 z-50 bg-black bg-opacity-80 flex items-center justify-center">
    <div class="bg-gray-900 p-8 rounded-lg shadow-lg text-center text-white max-w-md">
      <h2 class="text-2xl font-bold mb-4">✨ Hidden Alignment Achieved</h2>
      <p class="text-sm text-gray-300">You’ve unlocked the Complicompact Layer Zero. Welcome, Initiate.</p>
      <button class="mt-6 bg-pink-600 hover:bg-pink-700 px-4 py-2 rounded" @click="unlocked = false">
        Close
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const unlocked = ref(false);

onMounted(() => {
  const sequence = [38, 38, 40, 40, 37, 39, 37, 39, 66, 65];
  let input = [];

  window.addEventListener('keydown', e => {
    input.push(e.keyCode);
    if (input.toString().indexOf(sequence.toString()) >= 0) {
      unlocked.value = true;
      input = [];
    } else if (input.length > sequence.length) {
      input.shift();
    }
  });
});
</script>
