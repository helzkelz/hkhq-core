<template>
  <div class="bg-gradient-to-r from-purple-800 to-pink-700 rounded-lg p-4 shadow-md text-white">
    <h2 class="text-xl font-bold mb-2">Alignment Meter</h2>
    <div class="w-full h-4 bg-gray-800 rounded overflow-hidden">
      <div
        class="h-full bg-green-400 transition-all duration-700"
        :style="{ width: percentage + '%' }"
      ></div>
    </div>
    <p class="mt-2 text-sm text-gray-300">
      Alignment resonance at <strong>{{ percentage.toFixed(1) }}%</strong>.
    </p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const percentage = ref(0);

onMounted(() => {
  percentage.value = 47 + Math.random() * 53;
});
</script>
