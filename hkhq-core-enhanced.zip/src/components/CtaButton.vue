<template>
  <button
    class="bg-pink-600 hover:bg-pink-700 transition-all duration-200 px-5 py-2 rounded text-white font-semibold shadow-md focus:outline-none focus:ring-2 focus:ring-pink-400 focus:ring-offset-2"
    :disabled="disabled"
  >
    <slot />
  </button>
</template>

<script>
export default {
  name: 'CtaButton',
  props: {
    disabled: {
      type: Boolean,
      default: false
    }
  }
};
</script>
