<template>
  <div>
    <h1 class="text-3xl font-bold mb-4">Complicompact Dashboard</h1>
    <p class="text-gray-400 mb-6">Real-time metrics, supporter resonance levels, and alignment indicators.</p>

    <section class="bg-gray-800 p-6 rounded shadow mb-6">
      <h2 class="text-xl font-semibold text-white mb-2">Live Support Stats</h2>
      <p class="text-pink-400 font-mono">Currently resonating at $<span>{{ current }}</span> / $<span>{{ goal }}</span> ({{ percentage }}%)</p>
    </section>

    <section class="bg-gray-800 p-6 rounded shadow">
      <h2 class="text-xl font-semibold text-white mb-2">Incoming Alignment Signals</h2>
      <p class="text-sm text-gray-400 italic">No new transmissions detected. The void is... quiet.</p>
    </section>
  </div>
</template>

<script setup>
import { useSupportProgress } from '../composables/useSupportProgress.js';

const { current, goal, percentage } = useSupportProgress();
</script>
