<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">System Status</h1>
    <p class="text-gray-400">All systems nominal. Or at least pretending to be.</p>
  </div>
</template>

<script>
export default { name: 'Status' };
</script>
