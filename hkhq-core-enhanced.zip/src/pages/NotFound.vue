<template>
  <div class="text-center py-20">
    <h1 class="text-5xl font-bold mb-4">404</h1>
    <p class="text-gray-400">You’ve wandered off the map, but the map was abstract anyway.</p>
    <router-link to="/" class="mt-6 inline-block bg-pink-600 text-white px-6 py-2 rounded hover:bg-pink-700">
      Return to Order
    </router-link>
  </div>
</template>

<script>
export default { name: 'NotFound' };
</script>
