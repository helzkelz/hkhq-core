<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">Terms of Alignment</h1>
    <p class="text-gray-300 max-w-2xl">
      By engaging with this ecosystem, you agree to abide by mysterious and occasionally contradictory forces. Perks may vary. Alignment is not legally binding (yet).
    </p>
  </div>
</template>

<script>
export default { name: 'TermsOfAlignment' };
</script>
