<template>
  <div>
    <h1 class="text-3xl font-bold mb-6">Admin Control Deck</h1>
    <section class="mb-8 bg-gray-800 p-6 rounded shadow-md">
      <h2 class="text-xl font-semibold mb-2">Support Progress</h2>
      <p class="text-gray-400 text-sm mb-2">Live simulation of fundraising data.</p>
      <p class="text-pink-400 font-mono text-lg">$<span>{{ current }}</span> / $<span>{{ goal }}</span> ({{ percentage }}%)</p>
    </section>

    <section class="bg-gray-800 p-6 rounded shadow-md">
      <h2 class="text-xl font-semibold mb-2">Recent Inquiries</h2>
      <p class="text-sm text-gray-400 italic">Integration pending. This will display user-submitted cryptic requests.</p>
    </section>
  </div>
</template>

<script setup>
import { useSupportProgress } from '../composables/useSupportProgress.js';

const { current, goal, percentage } = useSupportProgress();
</script>
