<template>
  <div>
    <h1 class="text-4xl font-black mb-4 tracking-tight text-white">
      Welcome to Complicompact™
    </h1>
    <p class="text-gray-300 max-w-2xl mb-6 leading-relaxed">
      You’ve arrived at the <strong>hub</strong> of high-functioning chaos. This isn’t a landing page — it's a psychological assessment in disguise.
      Browse. Engage. Fund. Or just loiter — your presence is already data.
    </p>

    <div class="grid gap-4 md:grid-cols-2">
      <router-link to="/support" class="block bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-4 rounded text-lg font-semibold shadow transition">
        💸 Support the System
      </router-link>
      <router-link to="/inner-sanctum" class="block bg-gray-700 hover:bg-gray-600 text-white px-6 py-4 rounded text-lg font-semibold shadow transition">
        🤫 Enter the Inner Sanctum
      </router-link>
    </div>

    <div class="mt-10 text-sm text-gray-500 italic">
      (All glitches are immersive narrative elements. Enjoy the simulation.)
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home'
};
</script>
