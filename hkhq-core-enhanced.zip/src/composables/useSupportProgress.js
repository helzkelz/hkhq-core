import { ref, computed } from 'vue';

export function useSupportProgress(goalAmount = 1000, initialAmount = 630) {
  const current = ref(initialAmount);
  const goal = ref(goalAmount);

  const percentage = computed(() => Math.min(100, (current.value / goal.value) * 100).toFixed(1));

  function donate(amount) {
    current.value += amount;
  }

  return {
    current,
    goal,
    percentage,
    donate
  };
}
