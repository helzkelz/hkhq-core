import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import App from './App.vue';
import Home from './pages/Home.vue';
import Support from './pages/Support.vue';
import InnerSanctum from './pages/InnerSanctum.vue';
import Dashboard from './pages/Dashboard.vue';

const routes = [
  { path: '/', component: Home },
  { path: '/support', component: Support },
  { path: '/inner-sanctum', component: InnerSanctum },
  { path: '/dashboard', component: Dashboard },
  { path: '/:pathMatch(.*)*', redirect: '/' }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

createApp(App).use(router).mount('#app');
